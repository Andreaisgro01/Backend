package com.epicode.springField;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFieldApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFieldApplication.class, args);
	}

}
