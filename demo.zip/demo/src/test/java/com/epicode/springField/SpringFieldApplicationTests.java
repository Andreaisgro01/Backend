package com.epicode.springField;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFieldApplicationTests {

	@Test
	void contextLoads() {
	}

}
